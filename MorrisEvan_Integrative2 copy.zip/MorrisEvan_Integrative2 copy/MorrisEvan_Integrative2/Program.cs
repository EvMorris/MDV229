﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorrisEvan_Integrative2
{
    class Program
    {
        static void Main(string[] args)
        {
            Code code = new Code();
            Console.ReadKey();
        }
    }
}
